# Backend package for DiabetesAI Care
# This package contains the core backend components

__version__ = "1.0.0"

